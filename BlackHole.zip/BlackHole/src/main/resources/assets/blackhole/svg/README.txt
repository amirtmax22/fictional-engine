SVG sources. Export them to PNG (128x128 for logo/wings, 32x32 for icons), e.g.:
rsvg-convert -w 128 -h 128 logo.svg -o ../textures/icons/logo.png
