package com.blackhole.hud;

import com.blackhole.BlackHole;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.*;
import java.util.*;

public class HudManager {

    private final List<HudModule> modules = new ArrayList<>();
    private final File configFile = new File("config/blackhole_hud.json");
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public HudManager() {
        modules.add(new FpsModule());
        modules.add(new CpsModule());
        modules.add(new KeystrokesModule());
        modules.add(new PingModule());
    }

    public List<HudModule> getModules() { return modules; }

    @SubscribeEvent
    public void onMouse(MouseEvent event) {
        if (event.button == 0 && event.buttonstate) {
            CpsModule.clicks.add(System.currentTimeMillis());
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen == null && mc.thePlayer != null) {
            for (HudModule m : modules) {
                if (m.enabled) m.render(mc, m.x, m.y, m.scale, false);
            }
        }
    }

    public void save() {
        Map<String, float[]> data = new HashMap<>();
        for (HudModule m : modules) {
            data.put(m.id, new float[]{m.x, m.y, m.scale, m.enabled ? 1 : 0});
        }
        configFile.getParentFile().mkdirs();
        try (Writer w = new FileWriter(configFile)) {
            gson.toJson(data, w);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void load() {
        if (!configFile.exists()) return;
        try (Reader r = new FileReader(configFile)) {
            Map<String, float[]> data = gson.fromJson(r,
                    new TypeToken<Map<String, float[]>>() {}.getType());
            if (data == null) return;
            for (HudModule m : modules) {
                float[] v = data.get(m.id);
                if (v != null) {
                    m.x = v[0];
                    m.y = v[1];
                    m.scale = v[2];
                    m.enabled = v[3] > 0.5f;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ================= Modules =================

    public abstract static class HudModule {
        public final String id;
        public float x = 10, y = 10, scale = 1.0f;
        public boolean enabled = true;
        public final ResourceLocation icon;

        protected HudModule(String id, String iconName) {
            this.id = id;
            this.icon = new ResourceLocation(BlackHole.MODID, "textures/icons/" + iconName + ".png");
        }

        public abstract int getWidth();
        public abstract int getHeight();
        protected abstract void drawContent(FontRenderer f, boolean preview);

        public void render(Minecraft mc, float px, float py, float s, boolean preview) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(px, py, 0);
            GlStateManager.scale(s, s, 1);

            Gui.drawRect(0, 0, getWidth(), getHeight(), 0x88000000);
            Gui.drawRect(0, 0, getWidth(), 1, 0xFF7B2CFF);

            mc.getTextureManager().bindTexture(icon);
            GlStateManager.color(1, 1, 1, 1);
            Gui.drawModalRectWithCustomSizedTexture(3, 4, 0, 0, 12, 12, 12, 12);

            drawContent(mc.fontRendererObj, preview);
            GlStateManager.popMatrix();
        }
    }

    public static class FpsModule extends HudModule {
        public FpsModule() { super("fps", "fps"); }
        public int getWidth() { return 60; }
        public int getHeight() { return 20; }
        protected void drawContent(FontRenderer f, boolean p) {
            f.drawStringWithShadow(Minecraft.getDebugFPS() + " FPS", 19, 6, 0xFFFFFF);
        }
    }

    public static class CpsModule extends HudModule {
        public static final Deque<Long> clicks = new ArrayDeque<>();
        public CpsModule() { super("cps", "cps"); }
        public int getWidth() { return 60; }
        public int getHeight() { return 20; }
        protected void drawContent(FontRenderer f, boolean p) {
            long now = System.currentTimeMillis();
            while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
            int cps = p ? 12 : clicks.size();
            f.drawStringWithShadow(cps + " CPS", 19, 6, 0xFFFFFF);
        }
    }

    public static class PingModule extends HudModule {
        public PingModule() { super("ping", "ping"); }
        public int getWidth() { return 70; }
        public int getHeight() { return 20; }
        protected void drawContent(FontRenderer f, boolean p) {
            Minecraft mc = Minecraft.getMinecraft();
            int ping = (!p && mc.getCurrentServerData() != null) ? mc.getCurrentServerData().pingToServer : 42;
            f.drawStringWithShadow(ping + " ms", 19, 6, 0xFFFFFF);
        }
    }

    public static class KeystrokesModule extends HudModule {
        public KeystrokesModule() { super("keystrokes", "keys"); }
        public int getWidth() { return 62; }
        public int getHeight() { return 62; }

        protected void drawContent(FontRenderer f, boolean p) {
            GameSettings o = Minecraft.getMinecraft().gameSettings;
            drawKey(f, 21, 4, 16, "W", p || Keyboard.isKeyDown(o.keyBindForward.getKeyCode()));
            drawKey(f, 4, 21, 16, "A", p || Keyboard.isKeyDown(o.keyBindLeft.getKeyCode()));
            drawKey(f, 21, 21, 16, "S", p || Keyboard.isKeyDown(o.keyBindBack.getKeyCode()));
            drawKey(f, 38, 21, 16, "D", p || Keyboard.isKeyDown(o.keyBindRight.getKeyCode()));
            drawKey(f, 4, 40, 27, "LMB", p || Mouse.isButtonDown(0));
            drawKey(f, 33, 40, 25, "RMB", p || Mouse.isButtonDown(1));
        }

        private void drawKey(FontRenderer f, int x, int y, int w, String label, boolean down) {
            Gui.drawRect(x, y, x + w, y + 16, down ? 0xFFB388FF : 0x66000000);
            f.drawString(label, x + (w - f.getStringWidth(label)) / 2, y + 4, 0xFFFFFF);
        }
    }
}
