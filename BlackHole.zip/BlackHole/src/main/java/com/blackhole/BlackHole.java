package com.blackhole;

import com.blackhole.cosmetic.CosmeticManager;
import com.blackhole.gui.ClickGui;
import com.blackhole.hud.HudManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = BlackHole.MODID, name = BlackHole.NAME, version = BlackHole.VERSION, clientSideOnly = true)
public class BlackHole {
    public static final String MODID = "blackhole";
    public static final String NAME = "BlackHole";
    public static final String VERSION = "1.0.0";

    public static final KeyBinding OPEN_GUI =
            new KeyBinding("key.blackhole.open", Keyboard.KEY_RSHIFT, "BlackHole");

    public static HudManager hud;
    public static ClickGui gui;
    public static CosmeticManager cosmetics;

    @EventHandler
    public void init(FMLInitializationEvent event) {
        ClientRegistry.registerKeyBinding(OPEN_GUI);

        hud = new HudManager();
        cosmetics = new CosmeticManager();
        gui = new ClickGui();

        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(hud);
        MinecraftForge.EVENT_BUS.register(cosmetics);

        hud.load();
        cosmetics.load();
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (!OPEN_GUI.isPressed()) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen instanceof ClickGui) {
            mc.displayGuiScreen(null);
        } else if (mc.currentScreen == null) {
            mc.displayGuiScreen(gui);
        }
    }
}
