package com.blackhole.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Loops the Ton 618 background frames (assets/blackhole/bg/frame_000.png, frame_001.png, ...).
 * Frames are discovered automatically.
 */
public class BackgroundVideo {

    private static final float FPS = 24f;
    private static final int MAX_FRAMES = 600;

    private static ResourceLocation[] frames;

    private static void load() {
        if (frames != null) return;
        Minecraft mc = Minecraft.getMinecraft();
        List<ResourceLocation> list = new ArrayList<>();
        for (int i = 0; i < MAX_FRAMES; i++) {
            String path = String.format("/assets/blackhole/bg/frame_%03d.png", i);
            try (InputStream in = BackgroundVideo.class.getResourceAsStream(path)) {
                if (in == null) break;
                BufferedImage img = ImageIO.read(in);
                DynamicTexture tex = new DynamicTexture(img);
                list.add(mc.getTextureManager().getDynamicTextureLocation("bh_bg_" + i, tex));
            } catch (Exception e) {
                e.printStackTrace();
                break;
            }
        }
        frames = list.toArray(new ResourceLocation[0]);
    }

    public static void draw(int width, int height) {
        load();
        if (frames.length == 0) {
            Gui.drawRect(0, 0, width, height, 0xFF000000);
            return;
        }
        int idx = (int) ((System.currentTimeMillis() / 1000.0 * FPS) % frames.length);
        Minecraft.getMinecraft().getTextureManager().bindTexture(frames[idx]);
        GlStateManager.color(1, 1, 1, 1);
        Gui.drawModalRectWithCustomSizedTexture(0, 0, 0, 0, width, height, width, height);
        Gui.drawRect(0, 0, width, height, 0x66000000);
    }
}
