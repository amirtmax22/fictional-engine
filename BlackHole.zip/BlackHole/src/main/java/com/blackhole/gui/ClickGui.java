package com.blackhole.gui;

import com.blackhole.BlackHole;
import com.blackhole.hud.HudManager.HudModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;

import java.io.IOException;

public class ClickGui extends GuiScreen {

    private static final int TAB_HUD = 0, TAB_COSMETIC = 1;
    private static final int SLOTS = 4; // Off + 3 wings
    private int tab = TAB_HUD;

    private HudModule dragging = null;
    private float dragOffX, dragOffY;

    private boolean rotating = false;
    private int lastMx;
    private float previewYaw = 0;

    private final ResourceLocation logo = new ResourceLocation(BlackHole.MODID, "textures/icons/logo.png");

    @Override
    public void drawScreen(int mx, int my, float partial) {
        BackgroundVideo.draw(width, height);

        Minecraft.getMinecraft().getTextureManager().bindTexture(logo);
        GlStateManager.color(1, 1, 1, 1);
        Gui.drawModalRectWithCustomSizedTexture(width / 2 - 40, 10, 0, 0, 80, 80, 80, 80);
        drawCenteredString(fontRendererObj, "BlackHole", width / 2, 94, 0xFFB388FF);

        drawTab(width / 2 - 85, 112, "HUD", tab == TAB_HUD);
        drawTab(width / 2 + 5, 112, "Cosmetics", tab == TAB_COSMETIC);

        if (tab == TAB_HUD) drawHudTab(mx, my);
        else drawCosmeticTab();

        super.drawScreen(mx, my, partial);
    }

    private void drawTab(int x, int y, String name, boolean active) {
        Gui.drawRect(x, y, x + 80, y + 18, active ? 0xFF7B2CFF : 0x88000000);
        drawCenteredString(fontRendererObj, name, x + 40, y + 5, 0xFFFFFF);
    }

    // ================= HUD =================
    private void drawHudTab(int mx, int my) {
        for (HudModule m : BlackHole.hud.getModules()) {
            m.render(Minecraft.getMinecraft(), m.x, m.y, m.scale, true);
            if (inside(mx, my, m.x, m.y, m.getWidth() * m.scale, m.getHeight() * m.scale)) {
                Gui.drawRect((int) m.x - 1, (int) m.y - 1,
                        (int) (m.x + m.getWidth() * m.scale) + 1,
                        (int) (m.y + m.getHeight() * m.scale) + 1, 0x557B2CFF);
            }
        }
        drawCenteredString(fontRendererObj,
                "درگ = جابه‌جایی | اسکرول روی ماژول = بزرگ/کوچک | Right Shift = بستن",
                width / 2, height - 16, 0xAAAAAA);
    }

    // ================= Cosmetics =================
    private int slotX(int i) { return width / 2 - 165 + i * 85; }

    private void drawCosmeticTab() {
        int top = 140;
        for (int i = 0; i < SLOTS; i++) {
            int bx = slotX(i);
            boolean sel = BlackHole.cosmetics.getSelected() == i - 1;
            Gui.drawRect(bx, top, bx + 75, top + 75, sel ? 0xFF7B2CFF : 0x88000000);
            if (i == 0) {
                drawCenteredString(fontRendererObj, "Off", bx + 37, top + 30, 0xFFFFFF);
            } else {
                Minecraft.getMinecraft().getTextureManager().bindTexture(BlackHole.cosmetics.getWingTexture(i - 1));
                GlStateManager.color(1, 1, 1, 1);
                Gui.drawModalRectWithCustomSizedTexture(bx + 12, top + 6, 0, 0, 50, 50, 50, 50);
                drawCenteredString(fontRendererObj, "Wings " + i, bx + 37, top + 60, 0xFFFFFF);
            }
        }

        int py = Math.max(height - 20, 260);
        GuiInventory.drawEntityOnScreen(width / 2, py, 50,
                (float) (width / 2 - previewYaw), (float) (py - 60), Minecraft.getMinecraft().thePlayer);
        drawCenteredString(fontRendererObj, "درگ روی اسکین = چرخش", width / 2, height - 12, 0xAAAAAA);
    }

    private static boolean inside(int mx, int my, float x, float y, float w, float h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    // ================= Input =================
    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        if (btn != 0) return;

        if (my >= 112 && my <= 130) {
            if (mx >= width / 2 - 85 && mx <= width / 2 - 5) { tab = TAB_HUD; return; }
            if (mx >= width / 2 + 5 && mx <= width / 2 + 85) { tab = TAB_COSMETIC; return; }
        }

        if (tab == TAB_HUD) {
            for (HudModule m : BlackHole.hud.getModules()) {
                if (inside(mx, my, m.x, m.y, m.getWidth() * m.scale, m.getHeight() * m.scale)) {
                    dragging = m;
                    dragOffX = mx - m.x;
                    dragOffY = my - m.y;
                    return;
                }
            }
        } else {
            for (int i = 0; i < SLOTS; i++) {
                if (inside(mx, my, slotX(i), 140, 75, 75)) {
                    BlackHole.cosmetics.setSelected(i - 1);
                    return;
                }
            }
            if (my >= 200 && Math.abs(mx - width / 2) <= 70) {
                rotating = true;
                lastMx = mx;
            }
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (dragging != null) {
            dragging.x = Math.max(0, mx - dragOffX);
            dragging.y = Math.max(0, my - dragOffY);
        } else if (rotating) {
            previewYaw += (mx - lastMx) * 0.8f;
            lastMx = mx;
        }
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        dragging = null;
        rotating = false;
        BlackHole.hud.save();
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int dw = Mouse.getEventDWheel();
        if (dw != 0 && tab == TAB_HUD) {
            int mx = Mouse.getEventX() * width / mc.displayWidth;
            int my = height - Mouse.getEventY() * height / mc.displayHeight - 1;
            for (HudModule m : BlackHole.hud.getModules()) {
                if (inside(mx, my, m.x, m.y, m.getWidth() * m.scale, m.getHeight() * m.scale)) {
                    m.scale = Math.max(0.5f, Math.min(3f, m.scale + dw / 1200f));
                    BlackHole.hud.save();
                    break;
                }
            }
        }
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    @Override
    public void onGuiClosed() {
        BlackHole.hud.save();
        BlackHole.cosmetics.save();
    }
}
