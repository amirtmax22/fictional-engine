package com.blackhole.cosmetic;

import com.blackhole.BlackHole;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.io.*;

public class CosmeticManager {

    /** assets/blackhole/textures/cosmetic/wings_N.png  (N = 1..3) */
    private static final ResourceLocation[] WINGS = {
            new ResourceLocation(BlackHole.MODID, "textures/cosmetic/wings_1.png"),
            new ResourceLocation(BlackHole.MODID, "textures/cosmetic/wings_2.png"),
            new ResourceLocation(BlackHole.MODID, "textures/cosmetic/wings_3.png"),
    };

    private final File configFile = new File("config/blackhole_cosmetic.txt");
    private int selected = -1; // -1 = بدون کازمتیک

    public int getSelected() { return selected; }
    public void setSelected(int i) { selected = i; save(); }
    public ResourceLocation getWingTexture(int i) { return WINGS[i]; }

    public void save() {
        configFile.getParentFile().mkdirs();
        try (Writer w = new FileWriter(configFile)) {
            w.write(String.valueOf(selected));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void load() {
        if (!configFile.exists()) return;
        try (BufferedReader r = new BufferedReader(new FileReader(configFile))) {
            int v = Integer.parseInt(r.readLine().trim());
            if (v >= -1 && v < WINGS.length) selected = v;
        } catch (Exception ignored) {
        }
    }

    @SubscribeEvent
    public void onRenderPlayer(RenderPlayerEvent.Post event) {
        if (selected < 0) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (event.entityPlayer != mc.thePlayer) return;

        mc.getTextureManager().bindTexture(WINGS[selected]);
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableCull();
        GlStateManager.disableLighting();
        GlStateManager.color(1, 1, 1, 0.9f);

        // موقعیت بال‌ها روی پشت بازیکن. اگر جابه‌جا بود، این مقادیر را تنظیم کن.
        GlStateManager.rotate(-event.entityPlayer.renderYawOffset, 0, 1, 0);
        GlStateManager.translate(0, 1.1, -0.25);

        drawWing(0.0, 0.0, 0.85, 1.0, false); // بال راست
        drawWing(0.0, 0.0, 0.85, 1.0, true);  // بال چپ (آینه)

        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private void drawWing(double x0, double y0, double w, double h, boolean mirror) {
        double sign = mirror ? -1 : 1;
        double u0 = mirror ? 1 : 0, u1 = mirror ? 0 : 1;
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_TEX);
        wr.pos(x0, y0 + h, 0).tex(u0, 1).endVertex();
        wr.pos(x0 + sign * w, y0 + h, 0).tex(u1, 1).endVertex();
        wr.pos(x0 + sign * w, y0, 0).tex(u1, 0).endVertex();
        wr.pos(x0, y0, 0).tex(u0, 0).endVertex();
        t.draw();
    }
}
