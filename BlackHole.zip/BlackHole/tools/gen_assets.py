#!/usr/bin/env python3
"""Generates placeholder PNG assets (pure Python, no dependencies).
Replace the outputs with your own art / real Ton 618 frames when you have them."""
import math, os, struct, zlib, random

RES = os.path.join(os.path.dirname(__file__), '..', 'src', 'main', 'resources', 'assets', 'blackhole')

def save_png(path, w, h, buf):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    raw = b''.join(b'\x00' + bytes(buf[y * w * 4:(y + 1) * w * 4]) for y in range(h))
    def chunk(t, d):
        return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    data = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b''))
    with open(path, 'wb') as f:
        f.write(data)

def render(w, h, fn):
    buf = bytearray(w * h * 4)
    for y in range(h):
        for x in range(w):
            r, g, b, a = fn(x, y)
            i = (y * w + x) * 4
            buf[i:i + 4] = bytes((max(0, min(255, int(r))), max(0, min(255, int(g))),
                                  max(0, min(255, int(b))), max(0, min(255, int(a)))))
    return buf

def logo(x, y):
    cx, cy, d = x - 64, y - 64, math.hypot(x - 64, y - 64) / 64
    if d < 0.45: return (0, 0, 0, 255)
    ring = max(0, 1 - abs(d - 0.6) / 0.12)
    glow = max(0, 1 - abs(d - 0.6) / 0.35) * 0.3
    k = ring + glow
    return (179 * k, 44 * k, 255 * k, 255 * min(1, k + (0 if d > 0.45 else 1)) if k > 0 else 0)

def icon(color):
    def f(x, y):
        d = math.hypot(x - 16, y - 16)
        if d < 13: return (*color, 255)
        if d < 15: return (255, 255, 255, 160)
        return (0, 0, 0, 0)
    return f

def wing(tint):
    def f(x, y):
        # ساده: یک بیضی‌ی شکسته با پرهای موازی به‌عنوان جای‌نگهدار
        nx, ny = (x - 40) / 88, (y - 64) / 60
        inside = nx * nx + ny * ny < 1 and nx > -0.1
        feather = (math.sin((x + y * 0.3) * 0.25) + 1) * 0.5
        if inside:
            return (tint[0] * (0.6 + 0.4 * feather), tint[1] * (0.6 + 0.4 * feather), tint[2], 210)
        return (0, 0, 0, 0)
    return f

def bg_frame(t, w=480, h=270):
    cx, cy = w / 2, h / 2
    def f(x, y):
        dx, dy = x - cx, (y - cy) * 1.6
        d = math.hypot(dx, dy) / (h * 0.5)
        ang = math.atan2(dy, dx) + t * 0.6
        if d < 0.22:
            return (0, 0, 0, 255)
        disk = max(0, 1 - abs(d - 0.36) / 0.14) * (0.65 + 0.35 * math.sin(ang * 3))
        r, g, b = 255 * disk * 0.9, 150 * disk * 0.8, 60 * disk + 255 * disk * 0.3
        star = 0
        hsh = ((x * 73856093) ^ (y * 19349663)) & 0xffff
        if hsh < 60: star = 120 + (hsh % 120)
        return (r + star, g + star * 0.9, b + star, 255)
    return f

if __name__ == '__main__':
    random.seed(1)
    save_png(os.path.join(RES, 'textures', 'icons', 'logo.png'), 128, 128, render(128, 128, logo))
    for name, col in [('fps', (123, 44, 255)), ('cps', (179, 136, 255)),
                      ('keys', (100, 80, 220)), ('ping', (150, 90, 255))]:
        save_png(os.path.join(RES, 'textures', 'icons', name + '.png'), 32, 32, render(32, 32, icon(col)))
    tints = [(180, 120, 255), (120, 200, 255), (255, 160, 120)]
    for i, t in enumerate(tints, 1):
        save_png(os.path.join(RES, 'textures', 'cosmetic', f'wings_{i}.png'), 128, 128, render(128, 128, wing(t)))
    frames = 30
    for i in range(frames):
        save_png(os.path.join(RES, 'bg', f'frame_{i:03d}.png'), 480, 270,
                 render(480, 270, bg_frame(i / frames * 2 * math.pi)))
    print('assets generated')
