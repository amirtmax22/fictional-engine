# BlackHole — کلاینت Minecraft 1.8.9 (Forge)

## ساخت
- JDK 8 نصب کن.
- یک بار: `gradle wrapper --gradle-version 2.14.1` (یا Gradle 2.14.1 را دستی نصب کن).
- `./gradlew setupDecompWorkspace` و سپس `./gradlew build`.
- جار خروجی: `build/libs/BlackHole-1.0.0.jar` → داخل `mods/` ماینکرفت Forge 1.8.9.
- در GitHub هم با Actions خودکار ساخته می‌شود (تب Actions → Artifacts).

## ویدیوی Ton 618
`./tools/extract_frames.sh ton618-4k.mp4` (نیاز به ffmpeg). فریم‌های نمونه‌ی فعلی placeholder هستند.

## کلید
- `Right Shift` باز/بسته کردن منو.
- HUD: درگ برای جابه‌جایی، اسکرول روی ماژول برای بزرگ/کوچک کردن.
- Cosmetics: انتخاب بال، درگ روی اسکین برای چرخش.

## آیکن‌ها
فایل‌های `svg/` را با rsvg-convert به PNG تبدیل کن (توضیح در svg/README.txt).
